import java.util.*;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the extratype details");
		str=sc.nextLine();
		String[] res = str.split("[#]", 0);
		String name=res[0];
		long runs=Long.parseLong(res[1]);
		
		ExtraType et=new ExtraType(name,runs);
		et.setName(name);
		
		et.setRuns(runs);
		System.out.println("Enter the extratype details ");
		System.out.println("Extra Type:"+et.getName());
		System.out.println("Runs:"+et.getRuns());
		

	}

}
