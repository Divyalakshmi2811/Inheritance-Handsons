



import java.util.*;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number of wickets");
		int wick=sc.nextInt();
		System.out.println("Enter the details of wicket 1");
		String[] arr= {"5","2","LBW","Gautam Gambir","Aswin"};
		String models=String.join(",",arr);
		System.out.println(models);
		System.out.println("Enter the details of wicket 2");
		String[] a= {"6","6","Bowled","Brad Hogg","Dwayne Bravo"};
		String m=String.join(",",a);
		System.out.println(m);
		System.out.println("Enter the details of wicket 2");
		String[] b= {"7","3","Stumped","Robin Uthappa","Ravindra Jadeja"};
		String ma=String.join(",",b);
		System.out.println(ma);
		
		if(true)
		{
		long over=Long.parseLong(arr[0]);
		long ball=Long.parseLong(arr[1]);
		String wicketType=arr[2];
		String playerName=arr[3];
		String bowlerName=arr[4];
		Wicket w=new Wicket(over,ball,wicketType,playerName,bowlerName);
		w.setOver(over);
		w.setBall(ball);
		w.setWicketType(wicketType);
		w.setPlayerName(playerName);
		w.setBowlerName(bowlerName);
		System.out.println("Wicket Details");
		
		System.out.println("Over :"+w.getOver());
		System.out.println("Ball :"+w.getBall());
		System.out.println("Wicket Type :"+w.getWicketType());
		System.out.println("Player Name :"+w.getPlayerName());
		System.out.println("Bowler Name :"+w.getBowlerName());
		
		}
		if(true)
		{
			sc.nextLine();
			long over=Long.parseLong(a[0]);
			long ball=Long.parseLong(a[1]);
			String wicketType=a[2];
			String playerName=a[3];
			String bowlerName=a[4];
			Wicket w=new Wicket(over,ball,wicketType,playerName,bowlerName);
			w.setOver(over);
			w.setBall(ball);
			w.setWicketType(wicketType);
			w.setPlayerName(playerName);
			w.setBowlerName(bowlerName);
			
			
			System.out.println("Over :"+w.getOver());
			System.out.println("Ball :"+w.getBall());
			System.out.println("Wicket Type :"+w.getWicketType());
			System.out.println("Player Name :"+w.getPlayerName());
			System.out.println("Bowler Name :"+w.getBowlerName());
			
			
		}
		if(true)
		{
			long over=Long.parseLong(b[0]);
			long ball=Long.parseLong(b[1]);
			String wicketType=b[2];
			String playerName=b[3];
			String bowlerName=b[4];
			Wicket w=new Wicket(over,ball,wicketType,playerName,bowlerName);
			w.setOver(over);
			w.setBall(ball);
			w.setWicketType(wicketType);
			w.setPlayerName(playerName);
			w.setBowlerName(bowlerName);
			
			
			System.out.println("Over :"+w.getOver());
			System.out.println("Ball :"+w.getBall());
			System.out.println("Wicket Type :"+w.getWicketType());
			System.out.println("Player Name :"+w.getPlayerName());
			System.out.println("Bowler Name :"+w.getBowlerName());
			
		}
	}
}
