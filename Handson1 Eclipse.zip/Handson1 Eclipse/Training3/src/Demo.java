
public class Demo {

	public Demo( String name, String country, String skill) {
		super();
		
		this.name = name;
		this.country = country;
		this.skill = skill;
	}
	
	String name,country,skill;
	String str= "MS Dhoni,India,All Rounder";
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSkill() {
		return skill;
	}
	public void setSkill(String skill) {
		this.skill = skill;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	
}


