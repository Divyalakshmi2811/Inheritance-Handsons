import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub



	System.out.println("Enter the player details");
	    String str = "MS Dhoni,India,All Rounder";
	    System.out.println(str);
	    System.out.println("Player Details");
	       String[] res = str.split("[,]", 0);
	    Scanner sc=new Scanner(System.in); 
	    String name=res[0];
	    String skill=res[1];
	    String country=res[2];
	    
	       
	       Demo s=new Demo(name,skill,country);
	     s.setName(name);
	     s.setCountry(country);
	     s.setSkill(skill);
	      System.out.println("Player Name:"+s.getName());
	      System.out.println("Country Name:"+s.getCountry());
	      System.out.println("Skill:"+s.getSkill());
	    }

	}

