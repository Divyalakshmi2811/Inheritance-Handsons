import java.util.*;
public class Main {

	public static void main(String[] args) 
	{
		System.out.println("Enter the player name");
		Scanner sc=new Scanner(System.in); 
		String name=sc.nextLine();
		System.out.println("Enter the country name");
		String country=sc.nextLine();
		System.out.println("Enter the skill");
		String skill=sc.nextLine();
		Player p=new Player(name,country,skill);
		p.setName(name);
		p.setCountry(country);
		p.setSkill(skill);
		System.out.println("Player Details:");
		System.out.println("Player Name:"+p.getName());
		System.out.println("Country Name:"+p.getCountry());
		System.out.println("Skill:"+p.getSkill());


	}
}
	


