
		import java.util.*;
		public class Main {

			public static void main(String[] args) {
				// TODO Auto-generated method stub
				System.out.println("Enter the venue name");
				Scanner sc=new Scanner(System.in); 
				
				String name=sc.nextLine();
				System.out.println("Enter the city name");
				String city=sc.nextLine();
				Venue v=new Venue(name,city);
				v.setName(name);
				v.setCity(city);
				
				System.out.println("Venue Details:");
				System.out.println("Venue Name:"+v.getName());
				System.out.println("City Name:"+v.getCity());
			int ch;	

			do
			{
			
		System.out.println("Verify and Update Venue Details");
		System.out.println("Menu");
		System.out.println("1.Update Venue Name");
		System.out.println("2.Update City Name");
		System.out.println("3.All informations Correct/Exit");
		System.out.println("Type 1 or 2 or 3");
		 ch=sc.nextInt();
		 sc.nextLine();
		switch(ch)
		{
		case 1:
			System.out.println("Enter the venue name");
			 name=sc.nextLine();
			 v.setName(name);
		    System.out.println("Venue Details");
			System.out.println("Venue Name:"+v.getName());
			System.out.println("City Name:"+v.getCity());
			break;
		case 2:
			System.out.println("Enter the city name");
			city=sc.nextLine();
			v.setCity(city);
			System.out.println("Venue Details");
			System.out.println("Venue Name:"+v.getName());
			System.out.println("City Name:"+v.getCity());
			break;
		case 3:
			System.out.println("Venue Details");
			System.out.println("Venue Name:"+v.getName());
			System.out.println("City Name:"+v.getCity());
			break;
			
			
		}
			
			
		}while(ch<=3);
		
			
		
			}
		}
			
		

			
		


	


