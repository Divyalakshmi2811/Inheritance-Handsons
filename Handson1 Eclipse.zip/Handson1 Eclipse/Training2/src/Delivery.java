

	import java.util.*;
	public class Delivery
	{
	public long over,ball,runs;
	public String batsman,bowler,nonStriker;

	void displayDeliveryDetails()
	{

	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the over");
	over=sc.nextLong();
	System.out.println("Enter the ball");
	ball=sc.nextLong();
	System.out.println("Enter the runs");
	runs=sc.nextLong();
	sc.nextLine();
	System.out.println("Enter the batsman name");
	batsman=sc.nextLine();
	System.out.println("Enter the bowler name");
	bowler=sc.nextLine();
	System.out.println("Enter the nonStriker name");
	nonStriker=sc.nextLine();
	System.out.println("Delivery Details");
	System.out.println("Over:"+over);
	System.out.println("Ball:"+ball);
	System.out.println("Runs:"+runs);
	System.out.println("Batsman:"+batsman);
	System.out.println("Bowler:"+bowler);
	System.out.println("NonStriker:"+nonStriker);
	}
	}




