import java.util.*;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter the venue name");
		Scanner sc=new Scanner(System.in); 
		
		String name=sc.nextLine();
		System.out.println("Enter the city name");
		String city=sc.nextLine();
		Venue v=new Venue(name,city);
		v.setName(name);
		v.setCity(city);
		System.out.println("Venue Details:");
		System.out.println("Venue Name:"+v.getName());
		System.out.println("City Name:"+v.getCity());



	}

}
