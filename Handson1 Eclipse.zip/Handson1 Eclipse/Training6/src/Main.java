import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the over");
		long over=sc.nextLong();
		System.out.println("Enter the ball");
		long ball=sc.nextLong();
		System.out.println("Enter the runs");
		long runs=sc.nextLong();
		sc.nextLine();
		System.out.println("Enter the batsman name");
		String batsman=sc.nextLine();
		System.out.println("Enter the bowler name");
		String bowler=sc.nextLine();
		System.out.println("Enter the nonStriker name");
		String nonStriker=sc.nextLine();
		Delivery d=new Delivery(over,ball,runs,batsman,bowler,nonStriker);
		d.setOver(over);
		d.setBall(ball);
		d.setRuns(runs);
		d.setBatsman(batsman);
		d.setBowler(bowler);
		d.setNonStriker(nonStriker);
		System.out.println("Over :"+d.getOver());
		System.out.println("Ball :"+d.getBall());
		System.out.println("Runs :"+d.getRuns());
		System.out.println("Batsman :"+d.getBatsman());
		System.out.println("Bowler :"+d.getBowler());
		System.out.println("NonStriker :"+d.getNonStriker());
		
	}
}
